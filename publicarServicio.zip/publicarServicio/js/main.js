const formulario = document.getElementById('formulario');
const inputs = document.querySelectorAll('#formulario input');

const nServ = document.getElementsByName('nombreServicio')
const nombre = document.getElementsByName('nombrePersona');
const zona = document.getElementsByName('zona');
const telefono = document.getElementsByName('telefono');
const precio = document.getElementsByName('precio');
const descripcion = document.getElementsByName('descripcion');
const button = document.getElementById('publicar');

const expresiones = {
	nServ: /^[a-zA-Z0-9\_\-]{0,26}$/, // Letras, numeros, guion y guion_bajo
	nombre: /^[a-zA-ZÀ-ÿ\s]{0,40}$/, // Letras y espacios, pueden llevar acentos.
    zona: /^[a-zA-ZÀ-ÿ\s]{0,40}$/, // Letras y espacios, pueden llevar acentos.
	precio:  /^\d{0,14}$/, // 4 a 12 digitos.
	descripcion: /^[a-zA-Z0-9\_\-]{0,50}$/,
	telefono: /^\d{0,14}$/ // 7 a 14 numeros.
}

const validarFormulario = (e) => {
    switch (e.target.name) {
        case "nombreServicio":
            validarCampo(expresiones.nServ, e.target, 'nombreServicio', 'grupoServicio')
        break;
        case "nombrePersona":
            validarCampo(expresiones.nombre, e.target, 'nombrePersona', 'grupoNombre')
        break;
        case "zona":
            validarCampo(expresiones.zona, e.target, 'zona', 'grupoZona')
        break;
        case "telefono":
            validarCampo(expresiones.telefono, e.target, 'telefono', 'grupoTelefono')
        break;
        case "precio":
            validarCampo(expresiones.precio, e.target, 'precio', 'grupoPrecio')
        break;
        case "descripcion":
            validarCampo(expresiones.descripcion, e.target, 'descripcion', 'grupoDescripcion')
        break;  
    }
}

const validarCampo = (expresion, input, campo, campo2) => {
    if(expresion.test(input.value)){
        document.getElementById(`${campo}`).classList.remove('formulario_grupo-incorrecto')
        document.getElementById(`${campo2}`).classList.remove('formularioLetras_grupo-incorrecto')
    } else {
        document.getElementById(`${campo}`).classList.add('formulario_grupo-incorrecto')
        document.getElementById(`${campo2}`).classList.add('formularioLetras_grupo-incorrecto')
    }
};

inputs.forEach((input) => {
    input.addEventListener('keyup', validarFormulario);
    input.addEventListener('blur', validarFormulario);
})

formulario.addEventListener('submit', (e) => {
    e.preventDefault();
    if (Object.values(campos).every(value => value)) {
        formulario.reset();
        alert('Formulario enviado exitosamente');
    } else {
        alert('Por favor, completa correctamente todos los campos');
    }
});

button.addEventListener('click', (e) => {
    e.preventDefault()
    const data = {
        servicio: nServ.value,
        persona: nombre.value,
        zona: zona.value,
        telefono: telefono.value,
        precio: precio.value,
        descripcion: descripcion.value
    }

    console.log(data)
})