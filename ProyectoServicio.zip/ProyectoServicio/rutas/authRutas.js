const express = require('express');
const router = express.Router();
const authControlador = require('../controladores/authControlador');

// Ruta para el login
router.post('/login', authControlador.login);

// Ruta para registrar un nuevo usuario
router.post('/registro', authControlador.registrar);

module.exports = (db) => {
    return router;
};
