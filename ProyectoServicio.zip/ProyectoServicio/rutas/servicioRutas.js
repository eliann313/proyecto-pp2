const express = require('express');
const router = express.Router();
const servicioControlador = require('../controladores/servicioControlador');

// Crear un servicio (POST)
router.post('/crear', servicioControlador.crearServicio);

// Obtener todos los servicios (GET)
router.get('/', servicioControlador.obtenerServicios);

module.exports = (db) => {
    return router;
};
