const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Función para registrar un nuevo usuario
const registrar = async (req, res, next) => {
    try {
        const { nombre, email, contraseña } = req.body;

        if (!nombre || !email || !contraseña) {
            return res.status(400).json({ error: 'Faltan campos obligatorios' });
        }

        // Verificar si el correo ya existe
        const query = 'SELECT * FROM usuarios WHERE email = ?';
        db.query(query, [email], async (err, result) => {
            if (err) {
                return next(err);
            }
            if (result.length > 0) {
                return res.status(400).json({ error: 'El correo ya está registrado' });
            }

            const hashedContraseña = await bcrypt.hash(contraseña, 10);
            const queryInsert = 'INSERT INTO usuarios (nombre, email, contraseña) VALUES (?, ?, ?)';
            const values = [nombre, email, hashedContraseña];

            // Insertar el nuevo usuario
            db.query(queryInsert, values, (err, result) => {
                if (err) {
                    return next(err);
                }
                const token = jwt.sign({ id: result.insertId }, process.env.JWT_SECRET, { expiresIn: '1h' });
                res.status(201).json({ mensaje: 'Usuario registrado con éxito', token });
            });
        });
    } catch (error) {
        next(error);
    }
};

// Función para hacer login
const login = async (req, res, next) => {
    try {
        const { email, contraseña } = req.body;

        // Verificar el usuario
        const query = 'SELECT * FROM usuarios WHERE email = ?';
        db.query(query, [email], async (err, result) => {
            if (err) {
                return next(err);
            }
            if (result.length === 0) {
                return res.status(400).json({ error: 'Credenciales inválidas' });
            }

            const usuario = result[0];
            const esValidaContraseña = await bcrypt.compare(contraseña, usuario.contraseña);
            if (!esValidaContraseña) {
                return res.status(400).json({ error: 'Credenciales inválidas' });
            }

            const token = jwt.sign({ id: usuario.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
            res.status(200).json({ mensaje: 'Login exitoso', token });
        });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    registrar,
    login
};
