// Crear un servicio
const crearServicio = async (req, res, next) => {
    try {
        const { nombre, descripcion, categoria } = req.body;

        // Validaciones básicas
        if (!nombre || !descripcion || !categoria) {
            return res.status(400).json({ error: 'Faltan campos obligatorios' });
        }

        const query = 'INSERT INTO servicios (nombre, descripcion, categoria) VALUES (?, ?, ?)';
        const values = [nombre, descripcion, categoria];

        // Usamos la conexión a la base de datos
        db.query(query, values, (err, result) => {
            if (err) {
                return next(err);
            }
            res.status(201).json({ mensaje: 'Servicio creado con éxito', servicio: { id: result.insertId, nombre, descripcion, categoria } });
        });
    } catch (error) {
        next(error);
    }
};

// Obtener todos los servicios
const obtenerServicios = async (req, res, next) => {
    try {
        const query = 'SELECT * FROM servicios';

        // Usamos la conexión a la base de datos
        db.query(query, (err, results) => {
            if (err) {
                return next(err);
            }
            res.status(200).json(results);
        });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    crearServicio,
    obtenerServicios
};
