require('dotenv').config();
const express = require('express');
const app = express();
const cors = require('cors');
const authRutas = require('./rutas/authRutas');
const servicioRutas = require('./rutas/servicioRutas');
const errorMiddleware = require('./middleware/errorMiddleware');
const mysql = require('mysql2');

// Configuración del entorno


// Conexión a MySQL
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

db.connect(err => {
    if (err) {
        console.error('Error de conexión a la base de datos:', err);
    } else {
        console.log('Conexión exitosa a la base de datos MySQL');
    }
});

// Iniciar servidor

app.use(express.json());  // Para parsear el cuerpo de las peticiones como JSON

// Rutas
app.use('/api/servicios', servicioRutas(db));  // Ruta para manejar los servicios
app.use('/api/auth', authRutas(db));  // Ruta para manejar autenticación

// Middleware para manejar errores
app.use(errorMiddleware);

// Puerto de escucha
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Servidor en el puerto ${PORT}`);
});
