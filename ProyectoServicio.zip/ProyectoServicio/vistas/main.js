// main.js

const formulario = document.getElementById('formulario');
const inputs = document.querySelectorAll('#formulario input');

// Campos del formulario
const nServ = document.getElementsByName('nombreServicio');
const nombre = document.getElementsByName('nombrePersona');
const zona = document.getElementsByName('zona');
const telefono = document.getElementsByName('telefono');
const precio = document.getElementsByName('precio');
const descripcion = document.getElementsByName('descripcion');
const button = document.getElementById('publicar');

// Expresiones regulares para validación
const expresiones = {
    nServ: /^[a-zA-Z0-9\_\-]{0,26}$/, 
    nombre: /^[a-zA-ZÀ-ÿ\s]{0,40}$/, 
    zona: /^[a-zA-ZÀ-ÿ\s]{0,40}$/, 
    precio: /^\d{0,14}$/, 
    descripcion: /^[a-zA-Z0-9\_\-]{0,50}$/,
    telefono: /^\d{0,14}$/
};

// Firebase setup (Debes usar tu propia configuración de Firebase)
const firebaseConfig = {
    apiKey: "TU_API_KEY",
    authDomain: "TU_AUTH_DOMAIN",
    projectId: "TU_PROJECT_ID",
    storageBucket: "TU_STORAGE_BUCKET",
    messagingSenderId: "TU_MESSAGING_SENDER_ID",
    appId: "TU_APP_ID"
};

// Inicializar Firebase
firebase.initializeApp(firebaseConfig);

// Autenticación de usuario
const auth = firebase.auth();
const db = firebase.firestore();

// Manejar el estado de la autenticación
auth.onAuthStateChanged(user => {
    if (user) {
        // Si el usuario está autenticado, mostrar el perfil
        console.log("Usuario autenticado", user);
        mostrarPerfil(user);
    } else {
        // Si no está autenticado, redirigir al login
        window.location.href = "/login"; // Suponiendo que tienes una página de login
    }
});

// Función para mostrar el perfil de usuario y los servicios publicados
const mostrarPerfil = (user) => {
    db.collection('servicios').where("userId", "==", user.uid).get()
        .then(snapshot => {
            snapshot.forEach(doc => {
                console.log(doc.data());
                // Mostrar los servicios en el perfil del usuario
            });
        });
};

// Validar los campos del formulario
const validarFormulario = (e) => {
    switch (e.target.name) {
        case "nombreServicio":
            validarCampo(expresiones.nServ, e.target, 'nombreServicio', 'grupoServicio');
            break;
        case "nombrePersona":
            validarCampo(expresiones.nombre, e.target, 'nombrePersona', 'grupoNombre');
            break;
        case "zona":
            validarCampo(expresiones.zona, e.target, 'zona', 'grupoZona');
            break;
        case "telefono":
            validarCampo(expresiones.telefono, e.target, 'telefono', 'grupoTelefono');
            break;
        case "precio":
            validarCampo(expresiones.precio, e.target, 'precio', 'grupoPrecio');
            break;
        case "descripcion":
            validarCampo(expresiones.descripcion, e.target, 'descripcion', 'grupoDescripcion');
            break;  
    }
};

// Validación de campos
const validarCampo = (expresion, input, campo, campo2) => {
    if (expresion.test(input.value)) {
        document.getElementById(`${campo}`).classList.remove('formulario_grupo-incorrecto');
        document.getElementById(`${campo2}`).classList.remove('formularioLetras_grupo-incorrecto');
    } else {
        document.getElementById(`${campo}`).classList.add('formulario_grupo-incorrecto');
        document.getElementById(`${campo2}`).classList.add('formularioLetras_grupo-incorrecto');
    }
};

// Agregar eventos a los inputs
inputs.forEach((input) => {
    input.addEventListener('keyup', validarFormulario);
    input.addEventListener('blur', validarFormulario);
});

// Evento de envío del formulario
formulario.addEventListener('submit', (e) => {
    e.preventDefault();
    if (Object.values(campos).every(value => value)) {
        formulario.reset();
        alert('Formulario enviado exitosamente');
    } else {
        alert('Por favor, completa correctamente todos los campos');
    }
});

// Publicar un servicio
button.addEventListener('click', (e) => {
    e.preventDefault();

    const user = auth.currentUser;
    if (!user) {
        alert("Debes estar logueado para publicar un servicio");
        return;
    }

    const data = {
        userId: user.uid,
        servicio: nServ.value,
        persona: nombre.value,
        zona: zona.value,
        telefono: telefono.value,
        precio: precio.value,
        descripcion: descripcion.value,
        fecha: new Date()
    };

    // Guardar servicio en Firestore
    db.collection('servicios').add(data)
        .then(() => {
            alert('Servicio publicado correctamente');
            formulario.reset();
        })
        .catch(error => {
            console.error("Error al publicar el servicio: ", error);
        });
});

// Filtro de servicios por categoría
const filtroServicios = (categoria) => {
    db.collection('servicios').where("categoria", "==", categoria).get()
        .then(snapshot => {
            snapshot.forEach(doc => {
                console.log(doc.data());
                // Mostrar los servicios filtrados
            });
        });
};

// Llamar a filtro de servicios cuando se elige una categoría
document.getElementById('filtroServicios').addEventListener('change', (e) => {
    filtroServicios(e.target.value);
});
